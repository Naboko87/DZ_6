public abstract class Animals {
    String name_cat;
    String name_dog;
    int cat_run;
    int dog_run;
    String cat_swim;
    int dog_swim;



    public abstract void voice();

    public static void main(String[] args) {
        System.out.println("Вариант 1 решения, для подсчета");

        Cat[] cats = new Cat[3];
        cats[0] = new Cat("Барсик", "Белый", 200, "кот не умеет плавать");
        cats[1] = new Cat("Барсик", "Белый", 200, "кот не умеет плавать");
        cats[2] = new Cat("Барсик", "Белый", 200, "кот не умеет плавать");
        int b = 0;
        for(int i = 0; i < cats.length; i++) {
                System.out.println("Кот имя: " + cats[i].name_cat + ";" + " Кот цвет: " + cats[i].color + ";" + " Кот Бег: " + cats[i].cat_run + ";" +
                        " Кот Плавание: " + cats[i].cat_swim);
                b = i + 1;
        }
        System.out.println("Создано Котов: " + b);

        Dog[] dogs = new Dog[3];
        dogs[0] = new Dog("Шарик", "Черный", 500, 10);
        dogs[1] = new Dog("Шарик", "Черный", 500, 10);
        dogs[2] = new Dog("Шарик", "Черный", 500, 10);
        int c = 0;
        for(int i = 0; i < cats.length; i++) {
            System.out.println("Кот имя: " + dogs[i].name_dog + ";" + " Кот цвет: " + dogs[i].color + ";" + " Кот Бег: " + dogs[i].dog_run + ";" +
                    " Кот Плавание: " + dogs[i].dog_swim);
            c = i + 1;
        }
        System.out.println("Создано Собак: " + c);

        System.out.println();

        System.out.println("Вариант 2 решения без подсчета");

        Cat cat = new Cat("Барсик", "Белый", 200, "кот не умеет плавать");
        Dog dog = new Dog("Шарик", "Черный", 500, 10);
        cat.catInfo();
        cat.voice();
        dog.dogInfo();
        dog.voice();


    }




}


