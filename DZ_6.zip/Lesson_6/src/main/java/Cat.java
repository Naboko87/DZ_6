public class Cat extends Animals{
    String color;

    public Cat(String name_cat, String color, int cat_run, String cat_swim) {
        this.name_cat = name_cat;
        this.color = color;
        this.cat_run = cat_run;
        this.cat_swim = cat_swim;
    }

    public void catInfo() {
        System.out.println("Кот имя: " + name_cat +";" + " Кот цвет: " + color +";" + " Кот Бег: " + cat_run + ";" +
                " Кот Плавание: " + cat_swim);
    }

    @Override
    public void voice() {
        System.out.println("Кот мяукнул");
    }

}


