public class Dog extends Animals{
    String color;

    public Dog(String name_dog, String color, int dog_run, int dog_swim) {
        this.name_dog = name_dog;
        this.color = color;
        this.dog_run = dog_run;
        this.dog_swim = dog_swim;
    }

    public void dogInfo() {
        System.out.println("Собака имя: " + name_dog + ";" + " Собака цвет: " + color + ";" + " Собака пробежала: " + dog_run + " метров" + ";"  +
                " Собака Плавание: " + dog_swim + " метров ");
    }

    @Override
    public void voice() {

    }


}

